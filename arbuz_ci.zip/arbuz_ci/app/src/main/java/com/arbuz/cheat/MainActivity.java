package com.arbuz.cheat;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(13,13,13);
    private static final int PANEL = Color.rgb(29,29,29);
    private static final int RED = Color.rgb(245,45,55);
    // Set this to your own HTTPS API endpoint before using server authentication.
    private static final String VERIFY_URL =
    "https://itktpasdhilihrqckioz.supabase.co/functions/v1/verify-key";
    private EditText keyInput;
    private String getInstallationId() {
    android.content.SharedPreferences prefs =
        getSharedPreferences("arbuz_settings", MODE_PRIVATE);

    String id = prefs.getString("installation_id", null);

    if (id == null) {
        id = java.util.UUID.randomUUID().toString();
        prefs.edit().putString("installation_id", id).apply();
    }

    return id;
}
    private LinearLayout root, content;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showLogin();
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        t.setPadding(0, 7, 0, 7);
        return t;
    }

    private LinearLayout base() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(22, 28, 22, 22);
        l.setBackgroundColor(BG);
        return l;
    }

    private Button button(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 10, 0, 6); b.setLayoutParams(p);
        b.setOnClickListener(v -> r.run());
        return b;
    }

    private void showLogin() {
        root = base();
        root.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("ARBuz CHEAT", 30, RED, true);
        root.addView(title);
        root.addView(text("BETA 1.2  •  SERVER LOGIN", 12, Color.LTGRAY, true));
        View line = new View(this); line.setBackgroundColor(RED);
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(-1, 2);
        lineLp.setMargins(0, 12, 0, 18); root.addView(line, lineLp);

        TextView info = text("Введите персональный ключ ArbuzShop.", 14, Color.WHITE, false);
        root.addView(info);
        keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setHint("ArbuzShop + 10 цифр");
        keyInput.setHintTextColor(Color.GRAY);
        keyInput.setTextColor(Color.WHITE);
        keyInput.setPadding(14, 12, 14, 12);
        keyInput.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));
        root.addView(keyInput, new LinearLayout.LayoutParams(-1, -2));

        TextView status = text("Ключи проверяются сервером. Автономная проверка отключена.", 11, Color.LTGRAY, false);
        root.addView(status);
        Button login = button("ВОЙТИ", () -> {
            String key = keyInput.getText().toString().trim();
            if (!key.matches("ArbuzShop[0-9]{10}")) {
                status.setText("Неверный формат. Ожидается ArbuzShop и 10 цифр.");
                return;
            }
            status.setText("Проверка ключа…");
            login.setEnabled(false);
            verifyKey(key, status, login);
        });
        root.addView(login);
        root.addView(text("Серверный адрес нужно настроить перед реальным использованием.", 10, Color.GRAY, false));
        setContentView(root);
    }

    private void verifyKey(String key, TextView status, Button login) {
        new Thread(() -> {
            HttpURLConnection c = null;
            String message;
            boolean ok = false;
            try {
                URL url = new URL(VERIFY_URL);
                c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10000);
                c.setReadTimeout(10000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                c.setRequestProperty("apikey", "sb_publishable_RMX3aGldGlEyzrL5l4XCCA_L6OWoNzC");
                c.setRequestProperty("Authorization", "Bearer sb_publishable_RMX3aGldGlEyzrL5l4XCCA_L6OWoNzC");
                JSONObject payload = new JSONObject();
                payload.put("key", key);
                payload.put("installation_id", getInstallationId());
                byte[] bytes = payload.toString().getBytes("UTF-8");
                try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
                int code = c.getResponseCode();
                InputStream stream = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
                byte[] data = stream.readAllBytes();
                JSONObject response = new JSONObject(new String(data, "UTF-8"));
                ok = code == 200 && response.optBoolean("ok", false);
                message = ok ? "Ключ подтверждён. Доступ разрешён." :
                        response.optString("message", "Ключ недействителен или истёк.");
            } catch (Exception e) {
                message = "Нет связи с сервером. Проверьте HTTPS API и подключение.";
            } finally {
                if (c != null) c.disconnect();
            }
            final boolean accepted = ok;
            final String result = message;
            runOnUiThread(() -> {
                status.setText(result);
                login.setEnabled(true);
                if (accepted) showDashboard();
            });
        }).start();
    }

    private void showDashboard() {
        LinearLayout l = base();
        l.addView(text("ДОСТУП РАЗРЕШЁН", 24, RED, true));
        l.addView(text("ARBuz CHEAT • BETA 1.2", 12, Color.LTGRAY, true));
        l.addView(text("Самостоятельная панель управления. Игровые данные Oxide не считываются.", 13, Color.WHITE, false));
        l.addView(button("Разрешить плавающее окно", () -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, FloatingPanelService.class));
                Toast.makeText(this, "Плавающая панель запущена", Toast.LENGTH_SHORT).show();
            }
        }));
        l.addView(button("Открыть настройки ESP / HUD", () -> showModule("ESP / HUD",
                "Тестовые переключатели Boxes, Lines, Skeleton и Radar. Они меняют только демонстрационный интерфейс.")));
        l.addView(button("Открыть Aim Trainer", () -> showModule("AIM TRAINER",
                "Локальный тренажёр прицеливания, не управляющий Oxide.")));
        l.addView(button("Открыть Farm Demo", () -> showModule("FARM DEMO",
                "Демонстрация списка ресурсов и счётчика без автоматизации игрового процесса.")));
        l.addView(button("Выйти", this::showLogin));
        setContentView(l);
    }

    private void showModule(String title, String description) {
        LinearLayout l = base();
        l.addView(text(title, 23, RED, true));
        l.addView(text(description, 14, Color.WHITE, false));
        l.addView(button("Назад", this::showDashboard));
        setContentView(l);
    }

    @Override protected void onResume() {
        super.onResume();
        // If user returned from Android overlay-permission settings, they can start the panel from dashboard.
    }
}
