# Server API contract (not deployed)

The Android client is intentionally configured with a placeholder URL:
`https://YOUR_DOMAIN.example/api/v1/keys/verify`

Before real server authentication can work, deploy an HTTPS backend and replace `VERIFY_URL` in `MainActivity.java`.

## Request
`POST /api/v1/keys/verify`
Content-Type: application/json

```json
{ "key": "ArbuzShop1234567890" }
```

## Successful response
HTTP 200:
```json
{ "active": true, "plan": "lifetime", "expiresAt": null }
```

## Invalid/expired response
HTTP 401:
```json
{ "active": false, "message": "Key is invalid or expired" }
```

## Key management requirements
- Generate keys using a cryptographically secure random number generator.
- Store only a salted password hash (Argon2id or bcrypt), never plaintext keys.
- Enforce expiry and revocation on the server for every verification.
- Add rate limiting and audit logs.
- Use HTTPS only.
- Do not put an admin secret or signing secret in the Android APK.
- The example owner key shown in chat is not registered or activated by this project; add keys through your backend's admin process.
